import { Terminal } from '@/components/terminal'

export default function Page() {
  return (
    <main className="crt-overlay min-h-[100dvh] bg-background">
      <Terminal />
    </main>
  )
}
