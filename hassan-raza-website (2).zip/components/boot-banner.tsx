import { profile } from '@/lib/site-data'

const asciiName = String.raw`
 _   _    _    ____ ____    _    _   _
| | | |  / \  / ___/ ___|  / \  | \ | |
| |_| | / _ \ \___ \___ \ / _ \ |  \| |
|  _  |/ ___ \ ___) |__) / ___ \| |\  |
|_| |_/_/   \_\____/____/_/   \_\_| \_|
`

export function BootBanner() {
  return (
    <div className="flex flex-col gap-3">
      <pre className="overflow-x-auto text-[0.55rem] leading-tight text-primary sm:text-xs">
        {asciiName}
      </pre>
      <div className="flex flex-col gap-1">
        <p className="text-foreground">
          <span className="text-terminal-green">●</span> {profile.role}
        </p>
        <p className="text-muted-foreground text-pretty">{profile.tagline}</p>
      </div>
      <p className="text-muted-foreground">
        Type <span className="text-terminal-yellow">help</span> to see available commands, or try{' '}
        <span className="text-terminal-yellow">about</span>.
      </p>
    </div>
  )
}
