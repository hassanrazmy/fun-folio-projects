import type { ReactNode } from 'react'
import {
  about,
  experience,
  posts,
  profile,
  projects,
  skills,
  socials,
} from '@/lib/site-data'

function Link({ href, children }: { href: string; children: ReactNode }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="text-primary underline decoration-primary/40 underline-offset-4 transition-colors hover:decoration-primary"
    >
      {children}
    </a>
  )
}

function Row({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5 sm:flex-row sm:gap-3">
      <span className="w-28 shrink-0 text-muted-foreground">{label}</span>
      <span className="text-foreground">{value}</span>
    </div>
  )
}

export type Command = {
  description: string
  hidden?: boolean
  run: (args: string[]) => ReactNode
}

const helpEntries: { cmd: string; desc: string }[] = [
  { cmd: 'about', desc: 'who I am' },
  { cmd: 'skills', desc: 'languages & tools' },
  { cmd: 'projects', desc: 'things I have built' },
  { cmd: 'blog', desc: 'articles I have written' },
  { cmd: 'experience', desc: 'work history' },
  { cmd: 'contact', desc: 'how to reach me' },
  { cmd: 'whoami', desc: 'quick summary' },
  { cmd: 'ls', desc: 'list available sections' },
  { cmd: 'open <name>', desc: 'open a project or link' },
  { cmd: 'clear', desc: 'clear the terminal' },
  { cmd: 'help', desc: 'show this help menu' },
]

export const commands: Record<string, Command> = {
  help: {
    description: 'show available commands',
    run: () => (
      <div className="flex flex-col gap-1">
        <p className="text-muted-foreground">Available commands:</p>
        <div className="mt-1 flex flex-col gap-0.5">
          {helpEntries.map((e) => (
            <div key={e.cmd} className="flex gap-3">
              <span className="w-32 shrink-0 text-primary">{e.cmd}</span>
              <span className="text-muted-foreground">{e.desc}</span>
            </div>
          ))}
        </div>
        <p className="mt-2 text-muted-foreground">
          Tip: use <span className="text-terminal-yellow">Tab</span> to autocomplete and{' '}
          <span className="text-terminal-yellow">↑ / ↓</span> to browse history.
        </p>
      </div>
    ),
  },

  about: {
    description: 'who I am',
    run: () => (
      <div className="flex flex-col gap-1">
        {about.map((line, i) =>
          line === '' ? (
            <div key={i} className="h-2" />
          ) : (
            <p key={i} className="text-foreground text-pretty">
              {line}
            </p>
          ),
        )}
      </div>
    ),
  },

  skills: {
    description: 'languages & tools',
    run: () => (
      <div className="flex flex-col gap-2">
        {skills.map((s) => (
          <div key={s.group} className="flex flex-col gap-1 sm:flex-row sm:gap-3">
            <span className="w-24 shrink-0 text-muted-foreground">{s.group}</span>
            <div className="flex flex-wrap gap-2">
              {s.items.map((item) => (
                <span
                  key={item}
                  className="rounded-sm border border-border bg-secondary px-2 py-0.5 text-sm text-secondary-foreground"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
    ),
  },

  projects: {
    description: 'things I have built',
    run: () => (
      <div className="flex flex-col gap-4">
        {projects.map((p) => (
          <div key={p.name} className="flex flex-col gap-1 border-l-2 border-primary/40 pl-3">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-primary">~/{p.name}</span>
              {p.link ? <Link href={p.link}>[open]</Link> : null}
            </div>
            <p className="text-foreground text-pretty">{p.description}</p>
            <div className="flex flex-wrap gap-2">
              {p.stack.map((tech) => (
                <span key={tech} className="text-sm text-muted-foreground">
                  #{tech}
                </span>
              ))}
            </div>
          </div>
        ))}
        <p className="text-muted-foreground">
          Run <span className="text-terminal-yellow">open &lt;name&gt;</span> to visit a project.
        </p>
      </div>
    ),
  },

  blog: {
    description: 'articles I have written',
    run: () => (
      <div className="flex flex-col gap-4">
        {posts.map((post) => (
          <div key={post.title} className="flex flex-col gap-1">
            <div className="flex flex-wrap items-baseline gap-3">
              <span className="text-sm text-muted-foreground">{post.date}</span>
              {post.link ? (
                <Link href={post.link}>{post.title}</Link>
              ) : (
                <span className="text-foreground">{post.title}</span>
              )}
            </div>
            <p className="text-muted-foreground text-pretty">{post.summary}</p>
          </div>
        ))}
      </div>
    ),
  },

  experience: {
    description: 'work history',
    run: () => (
      <div className="flex flex-col gap-4">
        {experience.map((job) => (
          <div key={`${job.company}-${job.period}`} className="flex flex-col gap-1">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <span className="text-primary">
                {job.role} <span className="text-muted-foreground">@ {job.company}</span>
              </span>
              <span className="text-sm text-muted-foreground">{job.period}</span>
            </div>
            <ul className="flex flex-col gap-0.5">
              {job.points.map((pt, i) => (
                <li key={i} className="text-foreground text-pretty">
                  <span className="text-terminal-green">→</span> {pt}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    ),
  },

  contact: {
    description: 'how to reach me',
    run: () => (
      <div className="flex flex-col gap-1">
        <p className="text-muted-foreground">Let&apos;s build something. Reach me here:</p>
        <div className="mt-1 flex flex-col gap-1">
          {socials.map((s) => (
            <Row key={s.label} label={s.label} value={<Link href={s.url}>{s.handle}</Link>} />
          ))}
        </div>
      </div>
    ),
  },

  whoami: {
    description: 'quick summary',
    run: () => (
      <div className="flex flex-col gap-1">
        <Row label="name" value={profile.name} />
        <Row label="role" value={profile.role} />
        <Row label="location" value={profile.location} />
        <Row label="status" value={<span className="text-terminal-green">available for work</span>} />
      </div>
    ),
  },

  ls: {
    description: 'list available sections',
    run: () => (
      <div className="flex flex-wrap gap-x-6 gap-y-1">
        {['about', 'skills', 'projects', 'blog', 'experience', 'contact'].map((s) => (
          <span key={s} className="text-primary">
            {s}/
          </span>
        ))}
      </div>
    ),
  },

  open: {
    description: 'open a project or link',
    run: (args) => {
      const target = (args[0] ?? '').replace(/^~?\//, '').toLowerCase()
      if (!target) {
        return <span className="text-terminal-red">usage: open &lt;project-name&gt;</span>
      }
      const project = projects.find((p) => p.name.toLowerCase() === target)
      if (project?.link) {
        if (typeof window !== 'undefined') window.open(project.link, '_blank', 'noopener')
        return (
          <span className="text-muted-foreground">
            Opening <span className="text-primary">{project.name}</span> in a new tab…
          </span>
        )
      }
      return (
        <span className="text-terminal-red">
          open: {target}: no such project. Try <span className="text-terminal-yellow">projects</span>.
        </span>
      )
    },
  },

  echo: {
    description: 'print text',
    hidden: true,
    run: (args) => <span className="text-foreground">{args.join(' ')}</span>,
  },

  date: {
    description: 'show current date',
    hidden: true,
    run: () => <span className="text-foreground">{new Date().toString()}</span>,
  },

  sudo: {
    description: 'elevated access',
    hidden: true,
    run: () => (
      <span className="text-terminal-red">
        [sudo] password for guest: permission denied — nice try.
      </span>
    ),
  },
}

export const commandNames = Object.keys(commands)
