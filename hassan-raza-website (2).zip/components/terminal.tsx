'use client'

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type ReactNode,
} from 'react'
import { BootBanner } from '@/components/boot-banner'
import { commandNames, commands } from '@/components/commands'
import { profile } from '@/lib/site-data'

type HistoryEntry = {
  id: number
  input: string
  output: ReactNode
}

const navItems = ['about', 'skills', 'projects', 'blog', 'experience', 'contact', 'help']

function Prompt({ dim = false }: { dim?: boolean }) {
  return (
    <span className="shrink-0 whitespace-nowrap">
      <span className={dim ? 'text-muted-foreground' : 'text-terminal-green'}>
        {profile.handle}@{profile.host}
      </span>
      <span className="text-muted-foreground">:</span>
      <span className="text-terminal-blue">~</span>
      <span className="text-muted-foreground">$ </span>
    </span>
  )
}

export function Terminal() {
  const [history, setHistory] = useState<HistoryEntry[]>([])
  const [input, setInput] = useState('')
  const [commandLog, setCommandLog] = useState<string[]>([])
  const [logIndex, setLogIndex] = useState(-1)

  const idRef = useRef(0)
  const inputRef = useRef<HTMLInputElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const bottomRef = useRef<HTMLDivElement>(null)

  const suggestions = useMemo(() => {
    const trimmed = input.trim().toLowerCase()
    if (!trimmed || trimmed.includes(' ')) return []
    return commandNames.filter((c) => c.startsWith(trimmed) && c !== trimmed && !commands[c].hidden)
  }, [input])

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [history])

  const runCommand = useCallback((raw: string) => {
    const trimmed = raw.trim()
    if (!trimmed) {
      setHistory((prev) => [...prev, { id: idRef.current++, input: '', output: null }])
      return
    }

    setCommandLog((prev) => [...prev, trimmed])
    setLogIndex(-1)

    const [name, ...args] = trimmed.split(/\s+/)
    const lower = name.toLowerCase()

    if (lower === 'clear') {
      setHistory([])
      return
    }

    const command = commands[lower]
    const output: ReactNode = command ? (
      command.run(args)
    ) : (
      <span className="text-terminal-red">
        command not found: {name}. Type <span className="text-terminal-yellow">help</span> for options.
      </span>
    )

    setHistory((prev) => [...prev, { id: idRef.current++, input: trimmed, output }])
  }, [])

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.nativeEvent.isComposing || e.keyCode === 229) return

    if (e.key === 'Enter') {
      e.preventDefault()
      runCommand(input)
      setInput('')
      return
    }

    if (e.key === 'Tab') {
      e.preventDefault()
      if (suggestions.length > 0) setInput(suggestions[0])
      return
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (commandLog.length === 0) return
      const next = logIndex === -1 ? commandLog.length - 1 : Math.max(0, logIndex - 1)
      setLogIndex(next)
      setInput(commandLog[next])
      return
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (logIndex === -1) return
      const next = logIndex + 1
      if (next >= commandLog.length) {
        setLogIndex(-1)
        setInput('')
      } else {
        setLogIndex(next)
        setInput(commandLog[next])
      }
      return
    }

    if (e.key === 'l' && e.ctrlKey) {
      e.preventDefault()
      setHistory([])
    }
  }

  const focusInput = () => inputRef.current?.focus()

  const runFromNav = (name: string) => {
    runCommand(name)
    setInput('')
    focusInput()
  }

  return (
    <div className="mx-auto flex h-[100dvh] max-w-4xl flex-col p-3 sm:p-6">
      <div className="flex flex-1 flex-col overflow-hidden rounded-lg border border-border bg-card/60 shadow-2xl backdrop-blur-sm">
        {/* Title bar */}
        <div className="flex items-center gap-2 border-b border-border bg-secondary/50 px-4 py-2.5">
          <span className="h-3 w-3 rounded-full bg-terminal-red" aria-hidden />
          <span className="h-3 w-3 rounded-full bg-terminal-yellow" aria-hidden />
          <span className="h-3 w-3 rounded-full bg-terminal-green" aria-hidden />
          <span className="ml-2 truncate text-sm text-muted-foreground">
            {profile.handle}@{profile.host}: ~ — zsh
          </span>
        </div>

        {/* Clickable navigation — for visitors who prefer links over typing */}
        <nav
          aria-label="Site sections"
          className="flex flex-wrap items-center gap-x-1 gap-y-1 border-b border-border bg-secondary/30 px-3 py-2"
        >
          <span className="mr-1 select-none text-xs text-muted-foreground">click or type:</span>
          {navItems.map((name) => (
            <button
              key={name}
              type="button"
              onClick={() => runFromNav(name)}
              className="rounded-sm px-2 py-0.5 text-sm text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary focus-visible:bg-primary/10 focus-visible:text-primary focus-visible:outline-none"
            >
              {name}
            </button>
          ))}
          <button
            type="button"
            onClick={() => runFromNav('clear')}
            className="ml-auto rounded-sm px-2 py-0.5 text-sm text-muted-foreground transition-colors hover:bg-primary/10 hover:text-primary focus-visible:bg-primary/10 focus-visible:text-primary focus-visible:outline-none"
          >
            clear
          </button>
        </nav>

        {/* Terminal body */}
        <button
          type="button"
          aria-label="Focus terminal input"
          onClick={focusInput}
          className="min-h-0 flex-1 cursor-text text-left"
        >
          <div
            ref={scrollRef}
            className="terminal-scroll h-full overflow-y-auto px-4 py-4 text-sm leading-relaxed sm:text-[0.95rem]"
          >
            <div className="mb-4">
              <BootBanner />
            </div>

            <div className="flex flex-col gap-3">
              {history.map((entry) => (
                <div key={entry.id} className="flex flex-col gap-1">
                  {entry.input !== '' && (
                    <div className="flex gap-1">
                      <Prompt dim />
                      <span className="break-all text-foreground">{entry.input}</span>
                    </div>
                  )}
                  {entry.output != null && <div className="pl-0">{entry.output}</div>}
                </div>
              ))}
            </div>

            {/* Active input line */}
            <div className="mt-3 flex items-center gap-1">
              <Prompt />
              <div className="relative flex-1">
                <input
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  autoFocus
                  spellCheck={false}
                  autoComplete="off"
                  autoCapitalize="off"
                  aria-label="Terminal command input"
                  className="w-full bg-transparent text-foreground caret-transparent outline-none"
                />
                <span
                  className="pointer-events-none absolute top-0 text-primary"
                  style={{ left: `${input.length}ch` }}
                >
                  <span className="terminal-cursor">▊</span>
                </span>
              </div>
            </div>

            {/* Inline hint for the first suggestion */}
            {suggestions.length > 0 && (
              <div className="mt-1 pl-0 text-sm text-muted-foreground">
                <span className="text-terminal-yellow">Tab</span> → {suggestions.slice(0, 6).join('  ')}
              </div>
            )}

            <div ref={bottomRef} />
          </div>
        </button>
      </div>

      <p className="mt-3 text-center text-xs text-muted-foreground">
        {profile.name} · type <span className="text-primary">help</span> to get started
      </p>
    </div>
  )
}
