export const profile = {
  name: 'Hassan Raza',
  handle: 'hassan',
  host: 'hassan-raza.com',
  role: 'Full-Stack & WordPress Developer',
  location: 'Remote',
  tagline: 'I build fast, accessible web experiences — from custom WordPress themes to full-stack apps.',
  email: 'hello@hassan-raza.com',
}

export const about = [
  "I'm Hassan, a full-stack developer with deep roots in the WordPress ecosystem.",
  'I started by building custom themes and plugins, then grew into full-stack work with',
  'modern JavaScript, React, and Node. I care about performance, clean code, and shipping',
  'products that people actually enjoy using.',
  '',
  'These days I split my time between headless WordPress builds, React/Next.js apps, and',
  'helping teams speed up their sites and workflows.',
]

export const skills: { group: string; items: string[] }[] = [
  { group: 'languages', items: ['JavaScript', 'TypeScript', 'PHP', 'SQL', 'HTML/CSS'] },
  { group: 'frontend', items: ['React', 'Next.js', 'Tailwind CSS', 'Vue'] },
  { group: 'backend', items: ['Node.js', 'WordPress', 'REST APIs', 'GraphQL', 'MySQL'] },
  { group: 'tooling', items: ['Git', 'Docker', 'Vite', 'Webpack', 'Vercel'] },
]

export type Project = {
  name: string
  description: string
  stack: string[]
  link?: string
}

export const projects: Project[] = [
  {
    name: 'headless-commerce',
    description: 'A headless WordPress + Next.js storefront with sub-second page loads and a custom checkout.',
    stack: ['Next.js', 'WordPress', 'GraphQL', 'Stripe'],
    link: 'https://github.com/',
  },
  {
    name: 'theme-forge',
    description: 'A reusable WordPress starter theme with a block-first workflow and CI-driven deploys.',
    stack: ['PHP', 'WordPress', 'Sass', 'GitHub Actions'],
    link: 'https://github.com/',
  },
  {
    name: 'dash-metrics',
    description: 'A real-time analytics dashboard for agencies, aggregating data from multiple client sites.',
    stack: ['React', 'Node.js', 'PostgreSQL', 'Recharts'],
    link: 'https://github.com/',
  },
  {
    name: 'speed-audit',
    description: 'A CLI + web tool that audits WordPress sites and suggests concrete performance fixes.',
    stack: ['TypeScript', 'Lighthouse', 'Vercel'],
    link: 'https://github.com/',
  },
]

export type Post = {
  title: string
  date: string
  summary: string
  link?: string
}

export const posts: Post[] = [
  {
    title: 'Going Headless with WordPress and Next.js',
    date: '2025-11-02',
    summary: 'A practical guide to decoupling your WordPress backend from a modern React frontend.',
    link: 'https://hassan-raza.com',
  },
  {
    title: 'Cutting WordPress Load Times in Half',
    date: '2025-08-18',
    summary: 'The caching, asset, and query strategies I use to make WordPress genuinely fast.',
    link: 'https://hassan-raza.com',
  },
  {
    title: 'Writing Custom Gutenberg Blocks in 2025',
    date: '2025-05-30',
    summary: 'How to build maintainable, accessible custom blocks without fighting the editor.',
    link: 'https://hassan-raza.com',
  },
]

export type Job = {
  role: string
  company: string
  period: string
  points: string[]
}

export const experience: Job[] = [
  {
    role: 'Senior Full-Stack Developer',
    company: 'Freelance / Contract',
    period: '2021 — Present',
    points: [
      'Built headless WordPress + Next.js sites for agencies and startups.',
      'Led performance overhauls, cutting average load times by 40-60%.',
    ],
  },
  {
    role: 'WordPress Developer',
    company: 'Digital Agency',
    period: '2018 — 2021',
    points: [
      'Delivered 30+ custom themes and plugins for clients across industries.',
      'Mentored junior devs on modern PHP and block-based development.',
    ],
  },
  {
    role: 'Front-End Developer',
    company: 'Web Studio',
    period: '2016 — 2018',
    points: [
      'Turned designs into responsive, accessible interfaces.',
      'Introduced a component-based CSS system used across projects.',
    ],
  },
]

export const socials: { label: string; handle: string; url: string }[] = [
  { label: 'email', handle: 'hello@hassan-raza.com', url: 'mailto:hello@hassan-raza.com' },
  { label: 'github', handle: '@hassan-raza', url: 'https://github.com/' },
  { label: 'linkedin', handle: 'in/hassan-raza', url: 'https://linkedin.com/' },
  { label: 'x', handle: '@hassanraza', url: 'https://x.com/' },
  { label: 'website', handle: 'hassan-raza.com', url: 'https://hassan-raza.com' },
]
