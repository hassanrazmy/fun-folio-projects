import { useEffect, useRef, useState } from 'react';

export default function AboutSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.15 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-[#00d4ff] text-xs tracking-widest">// STAGE 01</span>
          <div className="flex-1 h-px bg-gradient-to-r from-[rgba(0,212,255,0.5)] to-transparent" />
          <span
            className="font-mono text-2xl font-bold text-white tracking-wider px-4 py-1 rounded-lg"
            style={{ background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(8px)' }}
          >ABOUT ME</span>
          <div className="flex-1 h-px bg-gradient-to-l from-[rgba(0,212,255,0.5)] to-transparent" />
        </div>

        <div
          className={`rounded-3xl p-8 md:p-12 transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}
          style={{ background: 'rgba(10,10,15,0.6)', backdropFilter: 'blur(18px)', border: '1px solid rgba(0,212,255,0.15)' }}
        >
          <div className="grid md:grid-cols-2 gap-16">
            {/* Avatar */}
            <div className="flex flex-col items-center justify-center">
              <div className="relative">
                <div className="absolute inset-0 rounded-full border-2 border-dashed border-[rgba(0,212,255,0.4)] animate-spin"
                  style={{ animationDuration: '12s', margin: '-16px' }} />
                <div className="absolute inset-0 rounded-full border border-[rgba(127,255,0,0.3)] animate-spin"
                  style={{ animationDuration: '8s', animationDirection: 'reverse', margin: '-30px' }} />
                <div className="w-48 h-48 md:w-56 md:h-56 rounded-full overflow-hidden border-4"
                  style={{ borderColor: '#00d4ff', boxShadow: '0 0 40px rgba(0,212,255,0.35)' }}>
                  <img
                    src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400"
                    alt="Hassan Raza"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 whitespace-nowrap font-mono text-xs bg-[rgba(0,212,255,0.15)] border border-[rgba(0,212,255,0.4)] text-[#00d4ff] px-3 py-1 rounded-full">
                  ● ONLINE
                </div>
              </div>

              <div className="mt-14 grid grid-cols-3 gap-4 w-full max-w-xs">
                {[{ label: 'YEARS EXP', val: '5+' }, { label: 'PROJECTS', val: '50+' }, { label: 'CLIENTS', val: '30+' }].map((stat) => (
                  <div key={stat.label} className="text-center p-3 rounded-xl border border-[rgba(0,212,255,0.2)] bg-[rgba(0,212,255,0.07)]">
                    <div className="font-mono font-bold text-xl text-[#00d4ff]">{stat.val}</div>
                    <div className="font-mono text-[9px] text-[rgba(255,255,255,0.4)] tracking-wider mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bio */}
            <div className="flex flex-col justify-center">
              <div className="font-mono text-[#7fff00] text-sm tracking-widest mb-4">PLAYER PROFILE</div>
              <h2 className="text-3xl font-bold text-white mb-6 leading-tight">
                Hi, I'm Hassan Raza —<br />
                <span className="text-[#00d4ff]">a passionate developer</span>
              </h2>
              <p className="text-[rgba(255,255,255,0.65)] leading-relaxed mb-5 font-light">
                I'm a Full Stack Developer with a love for crafting clean, performant digital experiences. With expertise spanning frontend and backend, I bring ideas to life through thoughtful engineering and creative problem-solving.
              </p>
              <p className="text-[rgba(255,255,255,0.65)] leading-relaxed mb-8 font-light">
                Whether building intuitive UIs with React or architecting scalable server-side systems, I thrive on turning complex requirements into elegant solutions.
              </p>
              <div className="space-y-3">
                {[{ key: 'LOCATION', val: 'Pakistan' }, { key: 'AVAILABILITY', val: 'Open to Opportunities' }, { key: 'LANGUAGES', val: 'English, Urdu' }].map((item) => (
                  <div key={item.key} className="flex items-center gap-4 font-mono text-sm">
                    <span className="text-[rgba(0,212,255,0.6)] w-32 flex-shrink-0">{item.key}:</span>
                    <span className="text-white">{item.val}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
