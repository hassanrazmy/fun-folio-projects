import { useEffect, useRef, useState } from 'react';
import { Mail, Github, Linkedin, Twitter, ExternalLink } from 'lucide-react';

const links = [
  { icon: Mail, label: 'EMAIL', value: 'hello@hassan-raza.com', href: 'mailto:hello@hassan-raza.com', color: '#00d4ff' },
  { icon: Github, label: 'GITHUB', value: 'github.com/hassanraza', href: '#', color: '#7fff00' },
  { icon: Linkedin, label: 'LINKEDIN', value: 'linkedin.com/in/hassanraza', href: '#', color: '#00d4ff' },
  { icon: Twitter, label: 'TWITTER', value: '@hassanraza_dev', href: '#', color: '#00d4ff' },
];

export default function ContactSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.1 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="contact" className="relative py-32 px-6 pb-40" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-[#00ffcc] text-xs tracking-widest">// FINAL STAGE</span>
          <div className="flex-1 h-px bg-gradient-to-r from-[rgba(0,255,204,0.5)] to-transparent" />
          <span className="font-mono text-2xl font-bold text-white tracking-wider px-4 py-1 rounded-lg"
            style={{ background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(8px)' }}>SEND MESSAGE</span>
          <div className="flex-1 h-px bg-gradient-to-l from-[rgba(0,255,204,0.5)] to-transparent" />
        </div>

        <div className={`rounded-3xl p-8 md:p-12 transition-all duration-1000 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}
          style={{ background: 'rgba(10,10,15,0.62)', backdropFilter: 'blur(18px)', border: '1px solid rgba(0,255,204,0.15)' }}>
          <div className="grid md:grid-cols-2 gap-16">
            {/* Left */}
            <div>
              <h3 className="text-3xl font-bold text-white mb-4 font-mono leading-tight">
                Let's build something<br />
                <span className="text-[#00ffcc]">extraordinary</span>
              </h3>
              <p className="text-[rgba(255,255,255,0.55)] leading-relaxed mb-10 font-light">
                Have a project in mind or want to collaborate? I'm always open to discussing new opportunities and creative ideas.
              </p>
              <div className="space-y-5">
                {links.map((link) => (
                  <a key={link.label} href={link.href} className="flex items-center gap-4 group">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:scale-110"
                      style={{ background: `${link.color}18`, border: `1px solid ${link.color}40` }}>
                      <link.icon size={16} style={{ color: link.color }} />
                    </div>
                    <div>
                      <div className="font-mono text-[10px] text-[rgba(255,255,255,0.4)] tracking-widest">{link.label}</div>
                      <div className="font-mono text-sm text-white group-hover:text-[#00ffcc] transition-colors">{link.value}</div>
                    </div>
                    <ExternalLink size={12} className="ml-auto text-[rgba(255,255,255,0.2)] group-hover:text-[#00ffcc] transition-colors" />
                  </a>
                ))}
              </div>
            </div>

            {/* Form */}
            <div>
              {sent ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-4 p-8 rounded-2xl border border-[rgba(0,255,204,0.3)] bg-[rgba(0,255,204,0.05)]">
                  <div className="font-mono text-5xl text-[#00ffcc]" style={{ textShadow: '0 0 20px #00ffcc' }}>★</div>
                  <h4 className="font-mono font-bold text-xl text-white">MESSAGE SENT!</h4>
                  <p className="font-mono text-sm text-[rgba(255,255,255,0.5)]">Thanks for reaching out. I'll get back to you soon.</p>
                  <button onClick={() => setSent(false)} className="mt-2 font-mono text-xs text-[#00ffcc] underline">Send another</button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  {(['name', 'email'] as const).map((field) => (
                    <div key={field}>
                      <label className="font-mono text-xs text-[rgba(255,255,255,0.4)] tracking-widest block mb-2 uppercase">{field}</label>
                      <input type={field === 'email' ? 'email' : 'text'} required value={form[field]}
                        onChange={(e) => setForm((f) => ({ ...f, [field]: e.target.value }))}
                        className="w-full bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.1)] rounded-xl px-4 py-3 font-mono text-sm text-white placeholder-[rgba(255,255,255,0.2)] focus:outline-none focus:border-[#00ffcc] transition-colors"
                        placeholder={field === 'email' ? 'player@example.com' : 'Your name'} />
                    </div>
                  ))}
                  <div>
                    <label className="font-mono text-xs text-[rgba(255,255,255,0.4)] tracking-widest block mb-2 uppercase">MESSAGE</label>
                    <textarea required rows={5} value={form.message}
                      onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
                      className="w-full bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.1)] rounded-xl px-4 py-3 font-mono text-sm text-white placeholder-[rgba(255,255,255,0.2)] focus:outline-none focus:border-[#00ffcc] transition-colors resize-none"
                      placeholder="Tell me about your project..." />
                  </div>
                  <button type="submit"
                    className="w-full py-4 font-mono font-bold text-sm tracking-widest uppercase rounded-xl transition-all duration-300 group relative overflow-hidden"
                    style={{ border: '2px solid #00ffcc' }}>
                    <span className="absolute inset-0 bg-[#00ffcc] translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                    <span className="relative z-10 text-[#00ffcc] group-hover:text-[#0a0a0f] transition-colors duration-300">▶ SEND MESSAGE</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-20 text-center">
          <div className="w-24 h-px bg-gradient-to-r from-transparent via-[rgba(255,255,255,0.15)] to-transparent mx-auto mb-6" />
          <p className="font-mono text-xs text-[rgba(255,255,255,0.2)] tracking-widest">
            © 2024 Hassan Raza — Crafted with code &amp; passion
          </p>
        </div>
      </div>
    </section>
  );
}
