import { useEffect, useRef, useState } from 'react';

const education = [
  {
    degree: 'Bachelor of Science in Computer Science',
    institution: 'University of the Punjab',
    period: '2015 — 2019',
    grade: 'CGPA: 3.6 / 4.0',
    icon: '🎓',
    color: '#00d4ff',
  },
  {
    degree: 'FSc Pre-Engineering',
    institution: 'Government College',
    period: '2013 — 2015',
    grade: 'A+ Grade',
    icon: '📚',
    color: '#7fff00',
  },
];

const certifications = [
  { name: 'Meta Front-End Developer', issuer: 'Coursera / Meta', year: '2023', color: '#00d4ff' },
  { name: 'AWS Cloud Practitioner', issuer: 'Amazon Web Services', year: '2022', color: '#ffd700' },
  { name: 'Full Stack Web Development', issuer: 'The Odin Project', year: '2021', color: '#7fff00' },
  { name: 'JavaScript Algorithms & Data Structures', issuer: 'freeCodeCamp', year: '2020', color: '#ff6b35' },
];

export default function EducationSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.1 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="education" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-[#ff1493] text-xs tracking-widest">// STAGE 05</span>
          <div className="flex-1 h-px bg-gradient-to-r from-[rgba(255,20,147,0.5)] to-transparent" />
          <span className="font-mono text-2xl font-bold text-white tracking-wider px-4 py-1 rounded-lg"
            style={{ background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(8px)' }}>ACHIEVEMENTS</span>
          <div className="flex-1 h-px bg-gradient-to-l from-[rgba(255,20,147,0.5)] to-transparent" />
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Education */}
          <div className={`rounded-3xl p-8 transition-all duration-700 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            style={{ background: 'rgba(10,10,15,0.62)', backdropFilter: 'blur(16px)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <h3 className="font-mono text-[rgba(255,255,255,0.4)] text-xs tracking-widest mb-7 uppercase">Education</h3>
            <div className="space-y-5">
              {education.map((edu, i) => (
                <div key={i} className="p-4 rounded-xl border border-[rgba(255,255,255,0.07)] hover:border-[rgba(0,212,255,0.3)] transition-all duration-300">
                  <div className="flex items-start gap-4">
                    <div className="w-11 h-11 rounded-lg flex items-center justify-center text-xl flex-shrink-0"
                      style={{ background: `${edu.color}18`, border: `1px solid ${edu.color}40` }}>
                      {edu.icon}
                    </div>
                    <div>
                      <h4 className="font-mono font-bold text-white text-sm leading-tight mb-1">{edu.degree}</h4>
                      <p className="font-mono text-sm mb-1" style={{ color: edu.color }}>{edu.institution}</p>
                      <div className="flex gap-4">
                        <span className="font-mono text-xs text-[rgba(255,255,255,0.4)]">{edu.period}</span>
                        <span className="font-mono text-xs text-[rgba(255,255,255,0.6)]">{edu.grade}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <div className={`rounded-3xl p-8 transition-all duration-700 delay-200 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
            style={{ background: 'rgba(10,10,15,0.62)', backdropFilter: 'blur(16px)', border: '1px solid rgba(255,255,255,0.08)' }}>
            <h3 className="font-mono text-[rgba(255,255,255,0.4)] text-xs tracking-widest mb-7 uppercase">Certifications</h3>
            <div className="space-y-3">
              {certifications.map((cert, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-xl border border-[rgba(255,255,255,0.06)] hover:border-[rgba(255,255,255,0.15)] transition-all duration-300">
                  <div className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ background: cert.color, boxShadow: `0 0 8px ${cert.color}` }} />
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm text-white truncate">{cert.name}</p>
                    <p className="font-mono text-xs text-[rgba(255,255,255,0.4)] mt-0.5">{cert.issuer}</p>
                  </div>
                  <span className="font-mono text-xs flex-shrink-0 px-2 py-1 rounded border"
                    style={{ color: cert.color, borderColor: `${cert.color}40`, background: `${cert.color}10` }}>
                    {cert.year}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
