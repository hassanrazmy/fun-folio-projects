import { useEffect, useRef, useState } from 'react';

const experiences = [
  {
    role: 'Senior Full Stack Developer',
    company: 'TechVentures Co.',
    period: '2022 — Present',
    location: 'Remote',
    type: 'FULL-TIME',
    points: [
      'Led development of a SaaS platform serving 10,000+ users using React, Node.js, and PostgreSQL',
      'Architected microservices infrastructure reducing system latency by 40%',
      'Mentored a team of 4 junior developers and established code review standards',
      'Integrated third-party payment gateways, auth systems, and analytics pipelines',
    ],
  },
  {
    role: 'Frontend Developer',
    company: 'DigitalCraft Agency',
    period: '2020 — 2022',
    location: 'Lahore, Pakistan',
    type: 'FULL-TIME',
    points: [
      'Built 20+ client websites with React, Next.js, and modern CSS animations',
      'Improved page load speeds by an average of 35% through performance optimization',
      'Collaborated with designers to implement pixel-perfect, responsive interfaces',
      'Introduced component-driven development with Storybook across the team',
    ],
  },
  {
    role: 'Web Developer (Freelance)',
    company: 'Self-employed',
    period: '2019 — 2020',
    location: 'Remote',
    type: 'FREELANCE',
    points: [
      'Delivered custom WordPress and React solutions for 15+ international clients',
      'Developed e-commerce stores with WooCommerce and Shopify integrations',
      'Maintained 5-star client ratings on Upwork and Fiverr platforms',
    ],
  },
];

export default function ExperienceSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.08 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="experience" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-[#ff6b35] text-xs tracking-widest">// STAGE 03</span>
          <div className="flex-1 h-px bg-gradient-to-r from-[rgba(255,107,53,0.5)] to-transparent" />
          <span className="font-mono text-2xl font-bold text-white tracking-wider px-4 py-1 rounded-lg"
            style={{ background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(8px)' }}>QUEST LOG</span>
          <div className="flex-1 h-px bg-gradient-to-l from-[rgba(255,107,53,0.5)] to-transparent" />
        </div>

        <div className="space-y-6">
          {experiences.map((exp, i) => (
            <div key={i}
              className={`rounded-2xl p-6 md:p-8 transition-all duration-700 group hover:border-[rgba(255,107,53,0.5)] ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'}`}
              style={{
                transitionDelay: `${i * 200}ms`,
                background: 'rgba(10,10,15,0.62)',
                backdropFilter: 'blur(16px)',
                border: '1px solid rgba(255,107,53,0.2)',
              }}>
              <div className="flex flex-wrap items-start justify-between gap-4 mb-5">
                <div>
                  <h3 className="font-mono font-bold text-xl text-white group-hover:text-[#ff6b35] transition-colors">{exp.role}</h3>
                  <p className="font-mono text-[#ff6b35] text-sm mt-1">{exp.company}</p>
                </div>
                <div className="text-right">
                  <span className="font-mono text-xs px-2 py-1 rounded border border-[rgba(255,107,53,0.4)] text-[rgba(255,107,53,0.8)]">{exp.type}</span>
                  <p className="font-mono text-xs text-[rgba(255,255,255,0.4)] mt-2">{exp.period}</p>
                  <p className="font-mono text-xs text-[rgba(255,255,255,0.3)] mt-0.5">{exp.location}</p>
                </div>
              </div>
              <ul className="space-y-2">
                {exp.points.map((point, j) => (
                  <li key={j} className="flex gap-3 text-sm text-[rgba(255,255,255,0.6)] font-light">
                    <span className="text-[#ff6b35] flex-shrink-0 mt-0.5">▸</span>
                    {point}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
