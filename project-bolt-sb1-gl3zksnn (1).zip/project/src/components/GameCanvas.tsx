import { useEffect, useRef } from 'react';

const COLORS = ['#00d4ff', '#ff6b35', '#7fff00', '#ffd700', '#ff1493', '#00ffcc'];

function rnd(a: number, b: number) { return a + Math.random() * (b - a); }
function rndInt(a: number, b: number) { return Math.floor(rnd(a, b)); }
function pickColor() { return COLORS[rndInt(0, COLORS.length)]; }

type Kind = 'coin' | 'star' | 'gem' | 'ring' | 'cube';

interface Item {
  kind: Kind;
  x: number; y: number;
  vx: number; vy: number;
  r: number;
  color: string;
  rot: number;
  rotSpeed: number;
  phase: number; // for bobbing/pulsing
}

function makeItem(W: number, H: number, kind: Kind): Item {
  const speed = rnd(1.2, 2.8);
  const angle = rnd(0, Math.PI * 2);
  return {
    kind,
    x: rnd(40, W - 40),
    y: rnd(40, H - 40),
    vx: Math.cos(angle) * speed,
    vy: Math.sin(angle) * speed,
    r: rnd(14, 28),
    color: pickColor(),
    rot: rnd(0, Math.PI * 2),
    rotSpeed: rnd(-0.035, 0.035) || 0.02,
    phase: rnd(0, Math.PI * 2),
  };
}

// --- Lightweight draw functions (NO shadowBlur) ---

function drawCoin(ctx: CanvasRenderingContext2D, item: Item) {
  const { x, y, r, color, rot } = item;
  const sx = Math.max(0.08, Math.abs(Math.cos(rot)));
  ctx.save();
  ctx.translate(x, y);
  ctx.scale(sx, 1);
  ctx.beginPath();
  ctx.ellipse(0, 0, r * 0.6, r, 0, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.4)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  // shine
  ctx.beginPath();
  ctx.ellipse(-r * 0.1, -r * 0.25, r * 0.12, r * 0.32, -0.3, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(255,255,255,0.35)';
  ctx.fill();
  ctx.restore();
}

function drawStar(ctx: CanvasRenderingContext2D, item: Item) {
  const { x, y, r, color, rot, phase } = item;
  const pulse = 1 + Math.sin(phase) * 0.12;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(pulse, pulse);
  ctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = (i * Math.PI) / 5 - Math.PI / 2;
    const rad = i % 2 === 0 ? r : r * 0.42;
    i === 0 ? ctx.moveTo(Math.cos(a) * rad, Math.sin(a) * rad)
             : ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
  }
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.45)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

function drawGem(ctx: CanvasRenderingContext2D, item: Item) {
  const { x, y, r, color, phase } = item;
  const bob = Math.sin(phase) * 5;
  ctx.save();
  ctx.translate(x, y + bob);
  ctx.beginPath();
  ctx.moveTo(0, -r);
  ctx.lineTo(r * 0.65, -r * 0.2);
  ctx.lineTo(r * 0.65, r * 0.28);
  ctx.lineTo(0, r);
  ctx.lineTo(-r * 0.65, r * 0.28);
  ctx.lineTo(-r * 0.65, -r * 0.2);
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.4)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  // top facet
  ctx.beginPath();
  ctx.moveTo(0, -r);
  ctx.lineTo(r * 0.65, -r * 0.2);
  ctx.lineTo(0, 0);
  ctx.closePath();
  ctx.fillStyle = 'rgba(255,255,255,0.2)';
  ctx.fill();
  ctx.restore();
}

function drawRing(ctx: CanvasRenderingContext2D, item: Item) {
  const { x, y, r, color, rot, phase } = item;
  const yscale = 0.55 + Math.abs(Math.sin(phase)) * 0.45;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  ctx.scale(1, yscale);
  ctx.beginPath();
  ctx.arc(0, 0, r, 0, Math.PI * 2);
  ctx.strokeStyle = color;
  ctx.lineWidth = r * 0.35;
  ctx.stroke();
  ctx.strokeStyle = 'rgba(255,255,255,0.4)';
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
}

function drawCube(ctx: CanvasRenderingContext2D, item: Item) {
  const { x, y, r, color, rot } = item;
  const s = r * 0.7;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(rot);
  // front
  ctx.fillStyle = color;
  ctx.fillRect(-s, -s, s * 2, s * 2);
  // top
  ctx.beginPath();
  ctx.moveTo(-s, -s);
  ctx.lineTo(-s + s * 0.6, -s - s * 0.5);
  ctx.lineTo(s + s * 0.6, -s - s * 0.5);
  ctx.lineTo(s, -s);
  ctx.closePath();
  ctx.fillStyle = 'rgba(255,255,255,0.2)';
  ctx.fill();
  // right
  ctx.beginPath();
  ctx.moveTo(s, -s);
  ctx.lineTo(s + s * 0.6, -s - s * 0.5);
  ctx.lineTo(s + s * 0.6, s - s * 0.5);
  ctx.lineTo(s, s);
  ctx.closePath();
  ctx.fillStyle = 'rgba(0,0,0,0.25)';
  ctx.fill();
  ctx.strokeStyle = 'rgba(255,255,255,0.2)';
  ctx.lineWidth = 1;
  ctx.strokeRect(-s, -s, s * 2, s * 2);
  ctx.restore();
}

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    let animId: number;
    let W = window.innerWidth;
    let H = window.innerHeight;

    canvas.width = W;
    canvas.height = H;

    const resize = () => {
      W = window.innerWidth;
      H = window.innerHeight;
      canvas.width = W;
      canvas.height = H;
    };
    window.addEventListener('resize', resize);

    // Exactly 30 items, 6 of each kind
    const kinds: Kind[] = ['coin', 'star', 'gem', 'ring', 'cube'];
    const items: Item[] = [];
    kinds.forEach((kind) => {
      for (let i = 0; i < 6; i++) items.push(makeItem(W, H, kind));
    });

    let tick = 0;

    function bounce(item: Item) {
      if (item.x - item.r < 0)  { item.x = item.r;      item.vx =  Math.abs(item.vx); }
      if (item.x + item.r > W)  { item.x = W - item.r;  item.vx = -Math.abs(item.vx); }
      if (item.y - item.r < 0)  { item.y = item.r;      item.vy =  Math.abs(item.vy); }
      if (item.y + item.r > H)  { item.y = H - item.r;  item.vy = -Math.abs(item.vy); }
    }

    function render() {
      tick++;
      ctx.clearRect(0, 0, W, H);

      // Background
      ctx.fillStyle = '#0a0a0f';
      ctx.fillRect(0, 0, W, H);

      // Static grid — draw once, no animation offset (cheap)
      ctx.strokeStyle = 'rgba(0,212,255,0.05)';
      ctx.lineWidth = 1;
      const step = 80;
      for (let x = 0; x < W; x += step) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
      }
      for (let y = 0; y < H; y += step) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
      }

      // Update & draw items
      for (const item of items) {
        item.x += item.vx;
        item.y += item.vy;
        item.rot += item.rotSpeed;
        item.phase += 0.04;
        bounce(item);

        switch (item.kind) {
          case 'coin':     drawCoin(ctx, item);     break;
          case 'star':     drawStar(ctx, item);     break;
          case 'gem':      drawGem(ctx, item);      break;
          case 'ring':     drawRing(ctx, item);     break;
          case 'cube':     drawCube(ctx, item);     break;
        }
      }

      animId = requestAnimationFrame(render);
    }

    render();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
