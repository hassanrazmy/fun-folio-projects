import { useEffect, useRef, useState } from 'react';

const roles = [
  'Full Stack Developer',
  'UI/UX Designer',
  'React Specialist',
  'Node.js Engineer',
  'Problem Solver',
];

export default function HeroSection() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [displayed, setDisplayed] = useState('');
  const [typing, setTyping] = useState(true);
  const charIndex = useRef(0);

  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout>;
    const current = roles[roleIndex];
    if (typing) {
      if (charIndex.current < current.length) {
        timeout = setTimeout(() => {
          setDisplayed(current.slice(0, charIndex.current + 1));
          charIndex.current++;
        }, 70);
      } else {
        timeout = setTimeout(() => setTyping(false), 1800);
      }
    } else {
      if (charIndex.current > 0) {
        timeout = setTimeout(() => {
          charIndex.current--;
          setDisplayed(current.slice(0, charIndex.current));
        }, 35);
      } else {
        setRoleIndex((i) => (i + 1) % roles.length);
        setTyping(true);
      }
    }
    return () => clearTimeout(timeout);
  }, [displayed, typing, roleIndex]);

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center text-center px-6"
    >
      {/* Glass card */}
      <div
        className="relative z-10 px-10 py-14 rounded-3xl max-w-2xl w-full"
        style={{
          background: 'rgba(10,10,15,0.55)',
          backdropFilter: 'blur(14px)',
          border: '1px solid rgba(0,212,255,0.25)',
          boxShadow: '0 0 60px rgba(0,212,255,0.08)',
        }}
      >
        <div className="mb-4">
          <span className="font-mono text-xs tracking-[0.35em] text-[rgba(0,212,255,0.7)] uppercase">
            &lt; Player One &gt;
          </span>
        </div>

        <h1
          className="font-mono font-black text-5xl md:text-7xl text-white mb-4 leading-none tracking-tight"
          style={{ textShadow: '0 0 40px rgba(0,212,255,0.4)' }}
        >
          Hassan
          <br />
          <span
            style={{
              backgroundImage: 'linear-gradient(90deg, #00d4ff, #7fff00)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            Raza
          </span>
        </h1>

        <div className="h-10 flex items-center justify-center mb-6">
          <span className="font-mono text-lg md:text-xl text-[rgba(255,255,255,0.8)]">
            {displayed}
            <span className="animate-pulse text-[#00d4ff]">|</span>
          </span>
        </div>

        <p className="text-[rgba(255,255,255,0.5)] font-mono text-sm leading-relaxed mb-10">
          Crafting digital experiences with clean code &amp; creative vision.<br />
          Press <span className="text-[#00d4ff]">START</span> to explore the journey.
        </p>

        <button
          onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
          className="group relative px-10 py-4 font-mono font-bold text-sm tracking-widest uppercase overflow-hidden rounded-xl"
          style={{ border: '2px solid #00d4ff' }}
        >
          <span className="absolute inset-0 bg-[#00d4ff] translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
          <span className="relative z-10 text-[#00d4ff] group-hover:text-[#0a0a0f] transition-colors duration-300">
            ▶ START GAME
          </span>
        </button>
      </div>

      {/* Score badge */}
      <div className="absolute top-28 right-8 font-mono text-xs text-[rgba(0,212,255,0.7)] border border-[rgba(0,212,255,0.25)] rounded-lg px-3 py-2 hidden md:block"
        style={{ background: 'rgba(10,10,15,0.6)', backdropFilter: 'blur(8px)' }}>
        <span className="text-[#ffd700]">★</span> LEVEL 1 &nbsp;|&nbsp; SCORE: <span className="text-[#7fff00]">9999</span>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
        <span className="font-mono text-[10px] text-[rgba(255,255,255,0.3)] tracking-widest">SCROLL</span>
        <div className="w-px h-8 bg-gradient-to-b from-[#00d4ff] to-transparent" />
      </div>
    </section>
  );
}
