import { useState, useEffect } from 'react';

const navItems = [
  { id: 'hero', label: 'HOME' },
  { id: 'about', label: 'ABOUT' },
  { id: 'skills', label: 'SKILLS' },
  { id: 'experience', label: 'EXP' },
  { id: 'projects', label: 'WORK' },
  { id: 'education', label: 'EDU' },
  { id: 'contact', label: 'CONTACT' },
];

interface NavBarProps {
  activeSection: string;
}

export default function NavBar({ activeSection }: NavBarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? 'bg-[rgba(10,10,15,0.92)] backdrop-blur-md border-b border-[rgba(0,212,255,0.15)]' : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <button
          onClick={() => scrollTo('hero')}
          className="font-mono text-[#00d4ff] font-bold text-lg tracking-widest hover:text-white transition-colors"
          style={{ textShadow: '0 0 12px #00d4ff' }}
        >
          HR<span className="text-white">.</span>
        </button>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className={`px-4 py-2 font-mono text-xs tracking-widest transition-all duration-300 rounded ${
                activeSection === item.id
                  ? 'text-[#00d4ff] bg-[rgba(0,212,255,0.1)]'
                  : 'text-[rgba(255,255,255,0.5)] hover:text-white hover:bg-[rgba(255,255,255,0.05)]'
              }`}
              style={activeSection === item.id ? { textShadow: '0 0 8px #00d4ff' } : {}}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Mobile */}
        <button
          className="md:hidden text-[#00d4ff] p-2"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <div className="space-y-1.5">
            <span className={`block w-6 h-0.5 bg-current transition-all ${menuOpen ? 'rotate-45 translate-y-2' : ''}`} />
            <span className={`block w-6 h-0.5 bg-current transition-all ${menuOpen ? 'opacity-0' : ''}`} />
            <span className={`block w-6 h-0.5 bg-current transition-all ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
          </div>
        </button>
      </div>

      {menuOpen && (
        <div className="md:hidden bg-[rgba(10,10,15,0.97)] border-b border-[rgba(0,212,255,0.15)] px-6 pb-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className={`block w-full text-left px-4 py-3 font-mono text-sm tracking-widest transition-colors ${
                activeSection === item.id ? 'text-[#00d4ff]' : 'text-[rgba(255,255,255,0.6)]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
}
