import { useEffect, useRef, useState } from 'react';

const projects = [
  {
    title: 'EduPlatform Pro',
    desc: 'Full-featured LMS with live classes, assignments, and real-time progress tracking for 5,000+ students.',
    tags: ['React', 'Node.js', 'PostgreSQL', 'Socket.io', 'AWS'],
    color: '#00d4ff',
    img: 'https://images.pexels.com/photos/4050315/pexels-photo-4050315.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'BOSS LEVEL',
  },
  {
    title: 'ShopSphere',
    desc: 'Multi-vendor e-commerce marketplace with Stripe payments and AI-powered product recommendations.',
    tags: ['Next.js', 'TypeScript', 'Prisma', 'Stripe', 'Redis'],
    color: '#7fff00',
    img: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'EPIC',
  },
  {
    title: 'TaskFlow',
    desc: 'Real-time project management with drag-and-drop boards, team collaboration, and smart automations.',
    tags: ['React', 'Express', 'MongoDB', 'WebSocket'],
    color: '#ffd700',
    img: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'RARE',
  },
  {
    title: 'HealthTrack',
    desc: 'Patient management system — appointment booking, digital prescriptions, analytics dashboard.',
    tags: ['Laravel', 'Vue.js', 'MySQL', 'Chart.js'],
    color: '#ff6b35',
    img: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'RARE',
  },
  {
    title: 'CryptoScan',
    desc: 'Real-time crypto tracker with portfolio management, price alerts, and interactive candlestick charts.',
    tags: ['React', 'WebSocket', 'Chart.js', 'CoinGecko API'],
    color: '#ff1493',
    img: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'UNCOMMON',
  },
  {
    title: 'DevBlog CMS',
    desc: 'Headless CMS and blogging platform with markdown support, SEO tools, and beautiful reading experience.',
    tags: ['Next.js', 'Sanity.io', 'Tailwind CSS'],
    color: '#00ffcc',
    img: 'https://images.pexels.com/photos/265667/pexels-photo-265667.jpeg?auto=compress&cs=tinysrgb&w=600',
    badge: 'COMMON',
  },
];

export default function ProjectsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [hovered, setHovered] = useState<number | null>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.05 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="projects" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-[#ffd700] text-xs tracking-widest">// STAGE 04</span>
          <div className="flex-1 h-px bg-gradient-to-r from-[rgba(255,215,0,0.5)] to-transparent" />
          <span className="font-mono text-2xl font-bold text-white tracking-wider px-4 py-1 rounded-lg"
            style={{ background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(8px)' }}>INVENTORY</span>
          <div className="flex-1 h-px bg-gradient-to-l from-[rgba(255,215,0,0.5)] to-transparent" />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {projects.map((project, i) => (
            <div key={project.title}
              className={`group relative rounded-2xl overflow-hidden transition-all duration-700 cursor-pointer ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-16'}`}
              style={{
                transitionDelay: `${i * 100}ms`,
                background: 'rgba(10,10,15,0.62)',
                backdropFilter: 'blur(16px)',
                border: `1px solid ${hovered === i ? project.color + '66' : 'rgba(255,255,255,0.08)'}`,
                boxShadow: hovered === i ? `0 0 30px ${project.color}22` : 'none',
                transition: 'all 0.35s',
              }}
              onMouseEnter={() => setHovered(i)}
              onMouseLeave={() => setHovered(null)}
            >
              {/* Badge */}
              <div className="absolute top-3 right-3 z-20 font-mono text-[9px] tracking-widest px-2 py-1 rounded-full border"
                style={{ color: project.color, borderColor: `${project.color}66`, background: `${project.color}15` }}>
                {project.badge}
              </div>

              {/* Image */}
              <div className="relative h-40 overflow-hidden">
                <img src={project.img} alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0" style={{ background: 'linear-gradient(to bottom, transparent 0%, rgba(10,10,15,0.85) 100%)' }} />
                {/* scanlines on hover */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-20 transition-opacity pointer-events-none"
                  style={{ backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,0,0,0.5) 2px, rgba(0,0,0,0.5) 4px)' }} />
              </div>

              {/* Content */}
              <div className="p-5">
                <h3 className="font-mono font-bold text-base text-white mb-2 transition-colors duration-300"
                  style={hovered === i ? { color: project.color } : {}}>
                  {project.title}
                </h3>
                <p className="text-[rgba(255,255,255,0.5)] text-sm leading-relaxed mb-4 font-light">{project.desc}</p>
                <div className="flex flex-wrap gap-1.5">
                  {project.tags.map((tag) => (
                    <span key={tag} className="font-mono text-[10px] px-2 py-0.5 rounded border border-[rgba(255,255,255,0.1)] text-[rgba(255,255,255,0.4)]">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              <div className="absolute bottom-0 left-0 right-0 h-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                style={{ background: `linear-gradient(90deg, transparent, ${project.color}, transparent)` }} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
