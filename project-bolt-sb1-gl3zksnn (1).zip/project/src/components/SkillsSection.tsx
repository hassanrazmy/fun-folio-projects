import { useEffect, useRef, useState } from 'react';

const skills = [
  { name: 'React / Next.js', level: 92, color: '#00d4ff', category: 'Frontend' },
  { name: 'TypeScript', level: 88, color: '#00d4ff', category: 'Frontend' },
  { name: 'Tailwind CSS', level: 90, color: '#00d4ff', category: 'Frontend' },
  { name: 'HTML / CSS', level: 95, color: '#00d4ff', category: 'Frontend' },
  { name: 'Node.js', level: 84, color: '#7fff00', category: 'Backend' },
  { name: 'Express.js', level: 82, color: '#7fff00', category: 'Backend' },
  { name: 'Laravel / PHP', level: 80, color: '#7fff00', category: 'Backend' },
  { name: 'PostgreSQL / MySQL', level: 78, color: '#7fff00', category: 'Backend' },
  { name: 'MongoDB', level: 75, color: '#7fff00', category: 'Backend' },
  { name: 'Git / GitHub', level: 90, color: '#ffd700', category: 'Tools' },
  { name: 'Docker', level: 70, color: '#ffd700', category: 'Tools' },
  { name: 'Figma / UI Design', level: 85, color: '#ffd700', category: 'Tools' },
];

const categories = ['Frontend', 'Backend', 'Tools'];

export default function SkillsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  const [activeCategory, setActiveCategory] = useState('Frontend');

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.1 });
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const filtered = skills.filter((s) => s.category === activeCategory);

  return (
    <section id="skills" className="relative py-32 px-6" ref={ref}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-16">
          <span className="font-mono text-[#7fff00] text-xs tracking-widest">// STAGE 02</span>
          <div className="flex-1 h-px bg-gradient-to-r from-[rgba(127,255,0,0.5)] to-transparent" />
          <span className="font-mono text-2xl font-bold text-white tracking-wider px-4 py-1 rounded-lg"
            style={{ background: 'rgba(10,10,15,0.7)', backdropFilter: 'blur(8px)' }}>SKILL TREE</span>
          <div className="flex-1 h-px bg-gradient-to-l from-[rgba(127,255,0,0.5)] to-transparent" />
        </div>

        <div className="rounded-3xl p-8 md:p-12"
          style={{ background: 'rgba(10,10,15,0.6)', backdropFilter: 'blur(18px)', border: '1px solid rgba(127,255,0,0.15)' }}>
          <div className="flex gap-2 mb-10 flex-wrap">
            {categories.map((cat) => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={`font-mono text-xs tracking-widest px-5 py-2.5 rounded-lg border transition-all duration-300 ${
                  activeCategory === cat
                    ? 'bg-[#7fff00] text-[#0a0a0f] border-[#7fff00]'
                    : 'text-[rgba(255,255,255,0.5)] border-[rgba(127,255,0,0.3)] hover:border-[#7fff00] hover:text-[#7fff00]'
                }`}>{cat.toUpperCase()}</button>
            ))}
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {filtered.map((skill, i) => (
              <div key={skill.name}
                className={`transition-all duration-700 ${visible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}
                style={{ transitionDelay: `${i * 80}ms` }}>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-mono text-sm text-white">{skill.name}</span>
                  <span className="font-mono text-xs" style={{ color: skill.color }}>{skill.level}%</span>
                </div>
                <div className="h-2.5 bg-[rgba(255,255,255,0.07)] rounded-full overflow-hidden">
                  <div className="h-full rounded-full relative transition-all duration-1000"
                    style={{
                      width: visible ? `${skill.level}%` : '0%',
                      background: `linear-gradient(90deg, ${skill.color}66, ${skill.color})`,
                      boxShadow: `0 0 10px ${skill.color}80`,
                      transitionDelay: `${i * 80 + 300}ms`,
                    }}>
                    <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 rounded-full"
                      style={{ background: skill.color, boxShadow: `0 0 6px ${skill.color}` }} />
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12">
            <p className="font-mono text-xs text-[rgba(255,255,255,0.35)] tracking-widest mb-5 text-center">ALSO FAMILIAR WITH</p>
            <div className="flex flex-wrap justify-center gap-3">
              {['REST APIs', 'GraphQL', 'Redux', 'Zustand', 'AWS', 'Vercel', 'Firebase', 'Supabase', 'Jest', 'Cypress', 'Webpack', 'Vite'].map((tech) => (
                <span key={tech}
                  className="font-mono text-xs px-3 py-1.5 rounded-lg border border-[rgba(255,255,255,0.1)] text-[rgba(255,255,255,0.45)] hover:border-[rgba(0,212,255,0.5)] hover:text-[#00d4ff] transition-all duration-300 cursor-default">
                  {tech}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
